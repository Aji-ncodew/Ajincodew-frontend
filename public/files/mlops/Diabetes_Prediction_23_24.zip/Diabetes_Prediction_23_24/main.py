import joblib
import numpy as np
import pandas as pd
from flask_cors import  cross_origin
from flask import Flask, request, render_template
import pickle

app = Flask(__name__)
# Charger le modèle préalablement entraîné
model = joblib.load('diabetes_model.pkl')
scaler = joblib.load('scaler.pkl')


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Récupérer les valeurs du formulaire
        Pregnancies = float(request.form['Pregnancies'])
        Glucose = float(request.form['Glucose'])
        BloodPressure = float(request.form['BloodPressure'])
        SkinThickness = float(request.form['SkinThickness'])
        Insulin = float(request.form['Insulin'])
        BMI = float(request.form['BMI'])
        DiabetesPedigreeFunction = float(request.form['DiabetesPedigreeFunction'])
        Age = float(request.form['Age'])

        # Créer un tableau numpy avec les valeurs
        data = np.array([[Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI, DiabetesPedigreeFunction, Age]])
        
        # Appliquer la même transformation que celle utilisée lors de l'entraînement
        scaled_data = scaler.transform(data)
        
        # Faire la prédiction
        prediction = model.predict(scaled_data)
        
        # Interpréter la prédiction
        if prediction[0] == 1:
            result = 'Diabétique'
        else:
            result = 'Non diabétique'

        return render_template('index.html', prediction_text=f'Prediction: {result}')

    except Exception as e:
        return render_template('index.html', prediction_text='Une erreur s\'est produite lors de la prédiction.')

if __name__ == '__main__':
    app.run(debug=True)
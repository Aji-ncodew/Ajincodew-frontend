# World Cup 2022 Predictions

## Data Sources

- [https://github.com/jfjelstul/worldcup]()
- [https://www.kaggle.com/datasets/cashncarry/fifaworldranking]()